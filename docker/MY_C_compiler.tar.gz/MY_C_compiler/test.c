#include<stdio.h>
int main(){
    int a;
    printf(a);
    return 0;
}
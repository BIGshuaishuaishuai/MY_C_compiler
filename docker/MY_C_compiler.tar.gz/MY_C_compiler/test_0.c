int temp(){
    int a = 2,b = 1,c;
    c = a * b;
    a = b / c;
    a = a + 1;
    b = b - 1;
    c + 6;
    
}
int main(){
    int i ;
    int a = 1,b = 1,tmp;
    tmp = temp();

    // tmp = a + b;
    for (i = 0; i < 10;i=i+1){
        int a;
        a = a + 1;
    }
    // a;
    tmp;
}

int mul(int n){
    int i = n;
    int j = 1;
    int a;
    if (i > j){
        a = mul(i - 1) * i;
    }
    else{
        a = i;
    }
    a;
}
// 主函数
int main() {
    int array[5] arr = {5, 4, 3, 2, 1};
    int n = 5;
    int res;
    mul(5);
    n = (*arr);
    n;
}
// test_3.c
int main(){
	int array[5] arr = {5, 4, 3, 2, 1};
    int c;
	for (c = 0;c < 6;c=c + 1){
		arr[c];
	}
}
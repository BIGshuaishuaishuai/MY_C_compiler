int main(){
	int array[5] arr = {5, 4, 3, 2, 1};
    int c;
	for (c = 0;c < 5;c=c + 1){
		arr[c] = arr[c] + 10;
	}
	arr[4];
}
